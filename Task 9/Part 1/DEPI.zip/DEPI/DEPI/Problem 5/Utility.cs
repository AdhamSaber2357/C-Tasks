﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DEPI.Problem_5
{
    public static class Utility
    {
        public static double CalculateRectanglePerimeter(double length, double width)
        {
            return 2 * (length + width);
        }
    }
}
