﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DEPI.Problem2_part2
{
    public class CustomStack<T>
    {
        private readonly List<T> _elements = new List<T>();

        public void Push(T item)
        {
            _elements.Add(item);
        }

        public T Pop()
        {
            if (IsEmpty())
                throw new InvalidOperationException("Stack is empty. Cannot pop element.");

            int lastIndex = _elements.Count - 1;
            T item = _elements[lastIndex];
            _elements.RemoveAt(lastIndex);
            return item;
        }

        public T Peek()
        {
            if (IsEmpty())
                throw new InvalidOperationException("Stack is empty. Cannot peek element.");

            return _elements[_elements.Count - 1];
        }

        public bool IsEmpty() => _elements.Count == 0;

        public int Count => _elements.Count;
    }
}
