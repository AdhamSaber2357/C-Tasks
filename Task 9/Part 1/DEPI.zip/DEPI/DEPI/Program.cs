﻿
using DEPI.Problem_13;
using DEPI.Problem_14;
using DEPI.Problem_3;
using DEPI.Problem_4;
using DEPI.Problem_5;
using DEPI.Problem_6;
using DEPI.Problem_9;
using DEPI.Problem2_part2;
using System;

namespace DEPI
{

    public enum Weekdays
    {
        Monday = 1,
        Tuesday,
        Wednesday,
        Thursday,
        Friday
    }

    public enum Grades : short
    {
        F = 1,
        D,   
        C, // 3
        B, // 4
        A  // 5
    }

    public enum GenderDefault
    {
        Male,
        Female
    }

    public enum GenderByte : byte
    {
        Male,
        Female
    }
    public struct Rectangle
    {
        public double Length { get; set; }
        public double Width { get; set; }

        public Rectangle(double length, double width)
        {
            Length = length;
            Width = width;
        }

        public override string ToString()
        {
            return $"[Length: {Length}, Width: {Width}]";
        }
    }
    class Program
    {

        
        public static void Swap(ref Rectangle rect1, ref Rectangle rect2)
        {
            Rectangle temp = rect1;
            rect1 = rect2;
            rect2 = temp;
        }

        public static T[] ReverseArray<T>(T[] array)
        {
            if (array == null) return null;

            T[] reversed = new T[array.Length];
            for (int i = 0; i < array.Length; i++)
            {
                reversed[i] = array[array.Length - 1 - i];
            }
            return reversed;
        }

        public static void Swap<T>(T[] array, int index1, int index2)
        {
            if (array == null)
                throw new ArgumentNullException(nameof(array), "Array cannot be null.");

            if (index1 < 0 || index1 >= array.Length || index2 < 0 || index2 >= array.Length)
                throw new IndexOutOfRangeException("Indices must be within the bounds of the array.");

            T temp = array[index1];
            array[index1] = array[index2];
            array[index2] = temp;
        }

        public static T FindMax<T>(T[] array) where T : IComparable<T>
        {
            if (array == null || array.Length == 0)
                throw new ArgumentException("Array cannot be null or empty.");

            T max = array[0];

            for (int i = 1; i < array.Length; i++)
            {
                if (array[i].CompareTo(max) > 0)
                {
                    max = array[i];
                }
            }

            return max;
        }
        static void Main(string[] args)
        {
            // Part 1

            #region p1
            //foreach (Weekdays day in Enum.GetValues(typeof(Weekdays)))
            //{
            //    int dayValue = (int)day;

            //    Console.WriteLine($"Day Name: {day,-10} | Value: {dayValue}");
            //}
            #endregion

            #region p2
            //foreach (Grades grade in Enum.GetValues(typeof(Grades)))
            //{
            //    short gradeValue = (short)grade;

            //    Console.WriteLine($"Grade Name: {grade,-5} | Numeric Value: {gradeValue}");
            //}
            #endregion

            #region p3
            //Person person1 = new Person("Adham", 20, "Computer Science");

            //Person person2 = new Person("Sarah", 22, "Software Engineering");

            //person1.DisplayDetails();
            //person2.DisplayDetails();
            #endregion

            #region p4
            //Child child = new Child();
            //child.Salary = 7500.50;
            //child.DisplaySalary();

            //Console.WriteLine();

            //GrandChild grandChild = new GrandChild();
            //grandChild.Salary = 9000;
            //grandChild.ShowGrandChildDetails();

            #endregion

            #region p5
            //double length = 5.0;
            //double width = 3.0;

            //double perimeter = Utility.CalculateRectanglePerimeter(length, width);

            //Console.WriteLine($"Length: {length}");
            //Console.WriteLine($"Width: {width}");
            //Console.WriteLine($"Rectangle Perimeter: {perimeter}");
            #endregion

            #region p6
            //ComplexNumber c1 = new ComplexNumber(3, 2);
            //ComplexNumber c2 = new ComplexNumber(1, 4);

            //ComplexNumber result = c1 * c2;

            //Console.WriteLine($"c1     = {c1}");
            //Console.WriteLine($"c2     = {c2}");
            //Console.WriteLine($"c1 * c2 = {result}");

            #endregion

            #region p7

            //int defaultEnumSize = sizeof(GenderDefault);
            //int byteEnumSize = sizeof(GenderByte);

            //Console.WriteLine($"1. Default Enum (int) Size : {defaultEnumSize} Byte(s)");
            //Console.WriteLine($"2. Modified Enum (byte) Size: {byteEnumSize} Byte(s)");

            //Console.WriteLine("\n--- Values & Underlying Types ---");

            //Console.WriteLine($"GenderDefault Type : {Enum.GetUnderlyingType(typeof(GenderDefault))}");
            //Console.WriteLine($"GenderByte Type    : {Enum.GetUnderlyingType(typeof(GenderByte))}");

            //GenderByte userGender = GenderByte.Male;
            //Console.WriteLine($"\nSample Value: {userGender} | Numeric Value: {(byte)userGender}");

            #endregion

            #region p8
            //string[] testInputs = { "A", "c", "F", "Z", "1", "10", "Excellent" };

            //foreach (var input in testInputs)
            //{
            //    // Enum.TryParse ترجع true لو نجح التحويل، و false لو فشل
            //    // ignoreCase: true بتخلي العملية مش حساسة لحالة الحروف (Capital/Small)
            //    if (Enum.TryParse<Grades>(input, ignoreCase: true, out Grades result) && Enum.IsDefined(typeof(Grades), result))
            //    {
            //        Console.WriteLine($"Input: '{input,-10}' => Successfully parsed to: {result} (Value: {(int)result})");
            //    }
            //    else
            //    {
            //        Console.WriteLine($"Input: '{input,-10}' => Invalid Grade!");
            //    }
            //}
            #endregion

            #region p9
            //DEPI.Problem_9. Employee[] employees = new DEPI.Problem_9.Employee[]
            // {
            //     new  DEPI.Problem_9.Employee(101, "Adham"),
            //     new  DEPI.Problem_9.Employee(102, "Sara"),
            //     new  DEPI.Problem_9.Employee(103, "Omar")
            // };

            // DEPI.Problem_9.Employee targetEmployee = new DEPI.Problem_9.Employee(102, "Sara");

            // int index = Helper2.SearchArray(employees, targetEmployee);

            // if (index != -1)
            // {
            //     Console.WriteLine($"Found '{targetEmployee.Name}' at index: {index}");
            // }
            // else
            // {
            //     Console.WriteLine("Employee not found!");
            // }
            #endregion


            #region p10

            //int maxInt = Helper2.Max(15, 42);
            //Console.WriteLine($"Max between 15 and 42         : {maxInt}");

            //double maxDouble = Helper2.Max(89.5, 23.4);
            //Console.WriteLine($"Max between 89.5 and 23.4     : {maxDouble}");

            //string maxString = Helper2.Max("Apple", "Zara");
            //Console.WriteLine($"Max between 'Apple' and 'Zara': {maxString}");

            #endregion

            #region p11
            //int[] numbers = { 10, 20, 30, 20, 40, 20 };
            //Console.WriteLine("Original Integers: " + string.Join(", ", numbers));

            //Helper2.ReplaceArray(numbers, 20, 99);
            //Console.WriteLine("After Replacing 20 with 99: " + string.Join(", ", numbers));

            //Console.WriteLine("\n----------------------------------------\n");

            //string[] names = { "Adham", "Sara", "Omar", "Sara", "Ali" };
            //Console.WriteLine("Original Strings: " + string.Join(", ", names));

            //Helper2.ReplaceArray(names, "Sara", "Nour");
            //Console.WriteLine("After Replacing 'Sara' with 'Nour': " + string.Join(", ", names));
            #endregion

            #region p12
            //Rectangle r1 = new Rectangle(10.5, 5.0);
            //Rectangle r2 = new Rectangle(20.0, 15.5);

            //Console.WriteLine($"Before Swap:");
            //Console.WriteLine($"r1: {r1}");
            //Console.WriteLine($"r2: {r2}");

            //Swap(ref r1, ref r2);

            //Console.WriteLine("\nAfter Swap:");
            //Console.WriteLine($"r1: {r1}");
            //Console.WriteLine($"r2: {r2}");
            #endregion

            #region p13
            //  Department csDept = new Department(101, "Computer Science");
            //  Department hrDept = new Department(102, "Human Resources");
            //  Department itDept = new Department(103, "Information Technology");

            //DEPI.Problem_13.Employee[] employees = new DEPI.Problem_13.Employee[]
            //  {
            //      new  DEPI.Problem_13. Employee(1, "Adham", csDept),
            //      new  DEPI.Problem_13. Employee(2, "Sara", hrDept),
            //      new  DEPI.Problem_13. Employee(3, "Omar", itDept)
            //  };

            //  Department searchDept = new Department(101, "Computer Science");
            //  DEPI.Problem_13.Employee dummyTarget = new DEPI.Problem_13.Employee(0, "", searchDept);

            //  int foundIndex = Helper.SearchArray(employees, dummyTarget);

            //  if (foundIndex != -1)
            //  {
            //      DEPI.Problem_13.Employee matchedEmployee = employees[foundIndex];
            //      Console.WriteLine($"Found employee in '{searchDept.DeptName}' department:");
            //      Console.WriteLine($"ID: {matchedEmployee.Id} | Name: {matchedEmployee.Name} | Index in Array: {foundIndex}");
            //  }
            //  else
            //  {
            //      Console.WriteLine("No employee found in the specified department.");
            //  }
            #endregion

            #region p14
            CircleStruct s1 = new CircleStruct(5.0, "Red");
            CircleStruct s2 = new CircleStruct(5.0, "Red");

            Console.WriteLine($"s1.Equals(s2) : {s1.Equals(s2)} (Compares Values)");
            Console.WriteLine($"s1 == s2       : {s1 == s2} (Overloaded == operator)");


            Console.WriteLine("\n=== 2. Testing Class (Reference Type) ===");
            CircleClass c1 = new CircleClass(5.0, "Red");
            CircleClass c2 = new CircleClass(5.0, "Red");
            CircleClass c3 = c1;

            Console.WriteLine($"c1.Equals(c2) : {c1.Equals(c2)} (Different references in Memory)");
            Console.WriteLine($"c1 == c2       : {c1 == c2} (Different references in Memory)");

            Console.WriteLine($"c1 == c3       : {c1 == c3} (Same reference in Memory)");
            #endregion


            // Part 2

            #region p1
            //int[] numbers = { 1, 2, 3, 4, 5 };
            //int[] reversedNumbers =ReverseArray(numbers);
            //Console.WriteLine("Original Ints : " + string.Join(", ", numbers));
            //Console.WriteLine("Reversed Ints : " + string.Join(", ", reversedNumbers));
            #endregion

            #region p2
            //CustomStack<int> intStack = new CustomStack<int>();
            //intStack.Push(10);
            //intStack.Push(20);
            //intStack.Push(30);

            //Console.WriteLine($"Top element (Peek) : {intStack.Peek()}");
            //Console.WriteLine($"Popped element     : {intStack.Pop()}");  
            //Console.WriteLine($"New top element    : {intStack.Peek()}");
            #endregion

            #region p3
            //int[] numbers = { 10, 20, 30, 40, 50 };
            //Console.WriteLine("Before Swap (Ints)   : " + string.Join(", ", numbers));
            //Swap(numbers, 1, 3);
            //Console.WriteLine("After Swap Index 1 & 3: " + string.Join(", ", numbers));
            #endregion

            #region p4
            //int[] numbers = { 15, 42, 8, 99, 23 };
            //int maxInt = FindMax(numbers);
            //Console.WriteLine("Array Ints : " + string.Join(", ", numbers));
            //Console.WriteLine($"Max Int    : {maxInt}");

            #endregion


        }






    }
}
