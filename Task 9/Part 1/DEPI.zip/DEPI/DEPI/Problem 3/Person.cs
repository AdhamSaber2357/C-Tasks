﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DEPI.Problem_3
{
    public class Person
    {
        public string Name { get; set; }
        public int Age { get; set; }
        public string Department { get; set; }

        public Person(string name, int age, string department)
        {
            Name = name;
            Age = age;
            Department = department;
        }

        public void DisplayDetails()
        {
            Console.WriteLine($"Name: {Name,-10} | Age: {Age,-3} | Department: {Department}");
        }
    }
}
