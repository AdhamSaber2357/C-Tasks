﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DEPI.Problem_9
{
    public class Employee
    {
        public int Id { get; set; }
        public string Name { get; set; }

        public Employee(int id, string name)
        {
            Id = id;
            Name = name;
        }

        public override bool Equals(object obj)
        {
            if (obj is Employee other)
            {
                return this.Id == other.Id && this.Name == other.Name;
            }
            return false;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(Id, Name);
        }
    }

    public static class Helper2
    {
        public static int SearchArray(Employee[] employees, Employee target)
        {
            if (employees == null || target == null) return -1;

            for (int i = 0; i < employees.Length; i++)
            {
                if (employees[i] != null && employees[i].Equals(target))
                {
                    return i;  
                }
            }
            return -1; 
        }

        public static T Max<T>(T val1, T val2) where T : IComparable<T>
        {
            return val1.CompareTo(val2) > 0 ? val1 : val2;
        }

        public static void ReplaceArray<T>(T[] array, T oldValue, T newValue)
        {
            if (array == null || array.Length == 0) return;

            for (int i = 0; i < array.Length; i++)
            {
                if (System.Collections.Generic.EqualityComparer<T>.Default.Equals(array[i], oldValue))
                {
                    array[i] = newValue;
                }
            }
        }
    }
}
