﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DEPI.Problem_14
{
    public struct CircleStruct
    {
        public double Radius { get; set; }
        public string Color { get; set; }

        public CircleStruct(double radius, string color)
        {
            Radius = radius;
            Color = color;
        }

        public static bool operator ==(CircleStruct c1, CircleStruct c2)
        {
            return c1.Radius == c2.Radius && c1.Color == c2.Color;
        }

        public static bool operator !=(CircleStruct c1, CircleStruct c2)
        {
            return !(c1 == c2);
        }

        public override bool Equals(object obj)
        {
            if (obj is CircleStruct other)
            {
                return this.Radius == other.Radius && this.Color == other.Color;
            }
            return false;
        }

        public override int GetHashCode() => HashCode.Combine(Radius, Color);
    }

    public class CircleClass
    {
        public double Radius { get; set; }
        public string Color { get; set; }

        public CircleClass(double radius, string color)
        {
            Radius = radius;
            Color = color;
        }
    }
}
