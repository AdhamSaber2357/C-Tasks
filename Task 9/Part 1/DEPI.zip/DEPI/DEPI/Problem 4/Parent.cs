﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DEPI.Problem_4
{
    public class Parent
    {
        public virtual double Salary { get; set; } = 5000;
    }

    public class Child : Parent
    {
        public sealed override double Salary
        {
            get => base.Salary;
            set => base.Salary = value;
        }

        public void DisplaySalary()
        {
            Console.WriteLine($"[Child Class] Current Salary: ${Salary:N2}");
        }
    }

    public class GrandChild : Child
    {
        public void ShowGrandChildDetails()
        {
            Console.WriteLine("GrandChild accessing Child's sealed salary:");
            DisplaySalary(); 
        }
    }
}