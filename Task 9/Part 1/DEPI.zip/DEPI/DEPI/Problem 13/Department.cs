﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DEPI.Problem_13
{
    public class Department
    {
        public int DeptId { get; set; }
        public string DeptName { get; set; }

        public Department(int deptId, string deptName)
        {
            DeptId = deptId;
            DeptName = deptName;
        }

        public override bool Equals(object obj)
        {
            if (obj is Department other)
            {
                return this.DeptId == other.DeptId && this.DeptName == other.DeptName;
            }
            return false;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(DeptId, DeptName);
        }
    }

    public class Employee
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public Department Department { get; set; }

        public Employee(int id, string name, Department department)
        {
            Id = id;
            Name = name;
            Department = department;
        }

        public override bool Equals(object obj)
        {
            if (obj is Employee other)
            {
                if (this.Department == null || other.Department == null)
                    return false;

                return this.Department.Equals(other.Department);
            }
            return false;
        }

        public override int GetHashCode()
        {
            return Department != null ? Department.GetHashCode() : 0;
        }
    }

    public static class Helper
    {
        public static int SearchArray(Employee[] employees, Employee target)
        {
            if (employees == null || target == null) return -1;

            for (int i = 0; i < employees.Length; i++)
            {
                if (employees[i] != null && employees[i].Equals(target))
                {
                    return i;
                }
            }
            return -1;
        }
    }
    }
