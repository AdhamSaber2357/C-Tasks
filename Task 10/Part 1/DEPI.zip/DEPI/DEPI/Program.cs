﻿using System;
using System.Collections.Generic;
using System.Linq;
using DEPI.Models;
using DEPI.Sorting;
using DEPI.Utilities;

namespace DEPI
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Problem01 - Sort Employee array by Salary using SortingAlgorithm<T>
            Console.WriteLine("Problem01: Sort Employee array by Salary (ascending) using SortingAlgorithm<T>");
            var employees = new Employee[] {
                new Employee(1, "Alice", 5000m),
                new Employee(2, "Bob", 3000m),
                new Employee(3, "Charlie", 4000m)
            };

            // Clone array before sorting to demonstrate cloning (constraint: T : ICloneable)
            var cloned = new Employee[employees.Length];
            for (int i = 0; i < employees.Length; i++)
                cloned[i] = (Employee)employees[i].Clone();

            SortingAlgorithm<Employee>.Sort(cloned, (a, b) => a.Salary.CompareTo(b.Salary));
            Console.WriteLine("Sorted by Salary:");
            foreach (var e in cloned) Console.WriteLine(e);
            #endregion

            #region Problem02 - Modify SortingTwo<T>.Sort to sort integers descending using lambda
            Console.WriteLine("\nProblem02: Sort integers descending using SortingTwo<T>.Sort with lambda");
            int[] nums = { 3, 1, 4, 2, 5 };
            // descending: larger numbers should come before smaller ones
            SortingTwo<int>.Sort(nums, (a, b) => a >= b);
            Console.WriteLine(string.Join(",", nums));
            #endregion

            #region Problem03 - Comparer to sort strings by length ascending using SortingTwo<T>.Sort
            Console.WriteLine("\nProblem03: Sort strings by length ascending using SortingTwo<T>.Sort");
            string[] words = { "apple", "kiwi", "banana", "fig" };
            SortingTwo<string>.Sort(words, (a, b) => a.Length <= b.Length);
            Console.WriteLine(string.Join(",", words));
            #endregion

            #region Problem04 - Add Manager inheriting Employee and implement IComparable<Manager>
            Console.WriteLine("\nProblem04: Manager inherits Employee and implements IComparable<Manager>");
            Employee[] mixed = new Employee[] {
                new Employee(10, "Eve", 4500m),
                new Models.Manager(11, "Frank", 6000m, "Sales"),
                new Models.Manager(12, "Grace", 4500m, "HR")
            };

            // Sort by Salary using SortingTwo with tie-breaker by Name
            SortingTwo<Employee>.Sort(mixed, (a, b) =>
            {
                if (a.Salary != b.Salary) return a.Salary <= b.Salary;
                return string.Compare(a.Name, b.Name, StringComparison.Ordinal) <= 0;
            });

            Console.WriteLine("Sorted mixed by Salary then Name:");
            foreach (var e in mixed) Console.WriteLine(e);
            #endregion

            #region Problem05 - Func<T,T,bool> to compare Employee by Name length and sort
            Console.WriteLine("\nProblem05: Sort employees by Name length using Func<Employee,Employee,bool>");
            var emps = new Employee[] {
                new Employee(21, "Ann", 2000m),
                new Employee(22, "Benjamin", 2500m),
                new Employee(23, "Cara", 2300m)
            };

            Func<Employee, Employee, bool> nameLenBefore = (a, b) => a.Name.Length <= b.Name.Length;
            SortingTwo<Employee>.Sort(emps, nameLenBefore);
            foreach (var e in emps) Console.WriteLine(e);
            #endregion

            #region Problem06 - Anonymous function to sort integer array ascending and lambda equivalent
            Console.WriteLine("\nProblem06: Anonymous function vs lambda for sorting integers ascending");
            int[] intsAnon = { 5, 2, 4, 1, 3 };
            // anonymous delegate
            SortingTwo<int>.Sort(intsAnon, delegate (int a, int b) { return a <= b; });
            Console.WriteLine("Anonymous sorted: " + string.Join(",", intsAnon));

            int[] intsLambda = { 9, 7, 8, 6 };
            SortingTwo<int>.Sort(intsLambda, (a, b) => a <= b);
            Console.WriteLine("Lambda sorted: " + string.Join(",", intsLambda));
            #endregion

            #region Problem07 - Demonstrate Swap<T> generic method
            Console.WriteLine("\nProblem07: Demonstrate Swap<T> by swapping integers");
            int[] arrSwap = { 1, 2, 3 };
            // call Swap method defined on SortingAlgorithm<Employee> (class generic parameter chosen to satisfy constraint)
            SortingAlgorithm<Employee>.Swap<int>(arrSwap, 0, 2);
            Console.WriteLine(string.Join(",", arrSwap));
            #endregion

            #region Problem08 - SortingTwo multi-criteria: Salary then Name
            Console.WriteLine("\nProblem08: Sort Employee by Salary then Name using SortingTwo<T>.Sort");
            var listMulti = new Employee[] {
                new Employee(31, "Zoe", 3000m),
                new Employee(32, "Adam", 3000m),
                new Employee(33, "Maya", 2500m)
            };
            SortingTwo<Employee>.Sort(listMulti, (a, b) =>
            {
                if (a.Salary != b.Salary) return a.Salary <= b.Salary;
                return string.Compare(a.Name, b.Name, StringComparison.Ordinal) <= 0;
            });
            foreach (var e in listMulti) Console.WriteLine(e);
            #endregion

            #region Problem09 - GetDefault demonstration
            Console.WriteLine("\nProblem09: GetDefault<T>() demonstration");
            Console.WriteLine($"default(int) = {DelegatesAndUtils.GetDefault<int>()}");
            Console.WriteLine($"default(string) = {DelegatesAndUtils.GetDefault<string>() ?? "null"}");
            #endregion

            #region Problem10 - Clone Employee array before sorting (constraint usage)
            Console.WriteLine("\nProblem10: Clone Employee array before sorting using ICloneable constraint");
            var toSort = new Employee[] { new Employee(41, "Ian", 1200m), new Employee(42, "Judy", 1100m) };
            var clones = new Employee[toSort.Length];
            for (int i = 0; i < toSort.Length; i++) clones[i] = (Employee)toSort[i].Clone();
            SortingAlgorithm<Employee>.Sort(clones, (a, b) => a.Salary.CompareTo(b.Salary));
            Console.WriteLine("Original:"); foreach (var e in toSort) Console.WriteLine(e);
            Console.WriteLine("Cloned & Sorted:"); foreach (var e in clones) Console.WriteLine(e);
            #endregion

            #region Problem11 - Delegate that takes string and returns string, apply transformations
            Console.WriteLine("\nProblem11: String transformations using Func<string,string>");
            var names = new List<string> { "one", "two", "three" };
            var upper = DelegatesAndUtils.ApplyStringFunc(names, s => s.ToUpperInvariant());
            var reversed = DelegatesAndUtils.ApplyStringFunc(names, s => new string(s.Reverse().ToArray()));
            Console.WriteLine("Upper: " + string.Join(",", upper));
            Console.WriteLine("Reversed: " + string.Join(",", reversed));
            #endregion

            #region Problem12 - Delegate that takes two ints and returns int
            Console.WriteLine("\nProblem12: Math operations via Func<int,int,int>");
            Func<int, int, int> add = (a, b) => a + b;
            Func<int, int, int> mul = (a, b) => a * b;
            Console.WriteLine(DelegatesAndUtils.Operate(4, 5, add));
            Console.WriteLine(DelegatesAndUtils.Operate(4, 5, mul));
            #endregion

            #region Problem13 - Generic delegate transform list T->R
            Console.WriteLine("\nProblem13: Transform list of ints to strings using generic delegate");
            var numbers = new List<int> { 1, 2, 3 };
            var asStrings = DelegatesAndUtils.TransformList<int, string>(numbers, n => $"#{n}");
            Console.WriteLine(string.Join(",", asStrings));
            #endregion

            #region Problem14 - Use Func<int,int> to square
            Console.WriteLine("\nProblem14: Func<int,int> square");
            Func<int, int> square = x => x * x;
            var squared = DelegatesAndUtils.TransformList(new[] { 2, 3, 4 }, square);
            Console.WriteLine(string.Join(",", squared));
            #endregion

            #region Problem15 - Use Action<string> to print
            Console.WriteLine("\nProblem15: Action<string> to print");
            DelegatesAndUtils.ApplyAction(new[] { "a", "b" }, s => Console.WriteLine("Action: " + s));
            #endregion

            #region Problem16 - Predicate<T> filter even numbers
            Console.WriteLine("\nProblem16: Predicate<int> filter even numbers");
            var evens = DelegatesAndUtils.Filter(new[] { 1, 2, 3, 4, 5 }, x => x % 2 == 0);
            Console.WriteLine(string.Join(",", evens));
            #endregion

            #region Problem17 - Filter strings with anonymous function
            Console.WriteLine("\nProblem17: Filter strings using anonymous function (start with 't')");
            var filtered = DelegatesAndUtils.Filter(new[] { "tom", "ann", "ted" }, delegate (string s) { return s.StartsWith("t"); });
            Console.WriteLine(string.Join(",", filtered));
            #endregion

            #region Problem18 - Math operation on two ints using anonymous function
            Console.WriteLine("\nProblem18: Anonymous function math operation");
            var resAnon = DelegatesAndUtils.Operate(6, 7, delegate (int a, int b) { return a - b; });
            Console.WriteLine(resAnon);
            #endregion

            #region Problem19 - Filter strings using lambda expression (length > 3 or contains 'e')
            Console.WriteLine("\nProblem19: Filter strings with lambda conditions");
            var sample = new[] { "apple", "pie", "egg", "data" };
            var longOnes = DelegatesAndUtils.Filter(sample, s => s.Length > 3);
            var containsE = DelegatesAndUtils.Filter(sample, s => s.Contains('e'));
            Console.WriteLine("Length>3: " + string.Join(",", longOnes));
            Console.WriteLine("Contains 'e': " + string.Join(",", containsE));
            #endregion

            #region Problem20 - Math on doubles using lambda (division, exponentiation)
            Console.WriteLine("\nProblem20: Math on doubles using lambda");
            Func<double, double, double> divide = (a, b) => a / b;
            Func<double, double, double> power = (a, b) => Math.Pow(a, b);
            Console.WriteLine(divide(9.0, 3.0));
            Console.WriteLine(power(2.0, 8.0));
            #endregion
        }
    }

}
