using System;

namespace DEPI.Sorting
{
    // Constrain T to ICloneable as requested in one of the problems
    public static class SortingAlgorithm<T> where T : ICloneable
    {
        // Basic selection sort using a Comparison<T> passed in
        public static void Sort(T[] array, Comparison<T> comparer)
        {
            if (array == null) throw new ArgumentNullException(nameof(array));
            if (comparer == null) throw new ArgumentNullException(nameof(comparer));

            int n = array.Length;
            for (int i = 0; i < n - 1; i++)
            {
                int minIdx = i;
                for (int j = i + 1; j < n; j++)
                {
                    if (comparer(array[j], array[minIdx]) < 0)
                        minIdx = j;
                }

                if (minIdx != i)
                    Swap(array, i, minIdx);
            }
        }

        // Standalone generic Swap method
        public static void Swap<U>(U[] array, int i, int j)
        {
            if (array == null) throw new ArgumentNullException(nameof(array));
            U tmp = array[i];
            array[i] = array[j];
            array[j] = tmp;
        }
    }
}
