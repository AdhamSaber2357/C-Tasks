using System;
using System.Collections.Generic;
using System.Text;

namespace DEPI.Models
{
    public class AnswerList : List<Answer>, ICloneable
    {
        public AnswerList() : base() { }

        public override string ToString()
        {
            var sb = new StringBuilder();
            for (int i = 0; i < Count; i++)
            {
                sb.AppendLine($"{i + 1}) {this[i].ToString()}");
            }
            return sb.ToString().TrimEnd();
        }

        public object Clone()
        {
            var clone = new AnswerList();
            foreach (var a in this)
                clone.Add((Answer)a.Clone());
            return clone;
        }
    }
}
