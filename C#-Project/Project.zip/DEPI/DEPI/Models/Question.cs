using System;
using System.Collections.Generic;

namespace DEPI.Models
{
    public enum QuestionMode { Draft, Active, Retired }

    public abstract class Question : ICloneable, IComparable<Question>
    {
        public string Header { get; set; }
        public string Body { get; set; }
        public int Marks { get; set; }
        public QuestionMode Mode { get; set; }
        public AnswerList Answers { get; set; }

        protected Question(string header, string body, int marks) : this(header, body)
        {
            Marks = marks;
        }

        protected Question(string header, string body)
        {
            Header = header;
            Body = body;
            Marks = 1;
            Answers = new AnswerList();
            Mode = QuestionMode.Draft;
        }

        public abstract string Display();

        public override string ToString()
        {
            return $"{GetType().Name}: {Header} ({Marks} pts)\n{Body}\n{Answers}";
        }

        public override bool Equals(object obj)
        {
            if (obj is Question q)
            {
                return Header == q.Header && Body == q.Body && Marks == q.Marks;
            }
            return false;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(Header, Body, Marks);
        }

        public virtual object Clone()
        {
            var clone = (Question)MemberwiseClone();
            clone.Answers = (AnswerList)Answers.Clone();
            return clone;
        }

        public int CompareTo(Question other)
        {
            if (other == null) return 1;
            // Compare by marks, then header
            var cmp = Marks.CompareTo(other.Marks);
            if (cmp != 0) return cmp;
            return string.Compare(Header, other.Header, StringComparison.Ordinal);
        }
    }
}
