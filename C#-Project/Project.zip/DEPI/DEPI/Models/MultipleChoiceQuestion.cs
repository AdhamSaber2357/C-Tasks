using System;
using System.Linq;

namespace DEPI.Models
{
    public class MultipleChoiceQuestion : Question
    {
        // store indexes of correct options
        public int[] CorrectIndexes { get; set; } = Array.Empty<int>();

        public MultipleChoiceQuestion(string header, string body, int marks) : base(header, body, marks)
        {
        }

        public void SetOptions(params string[] options)
        {
            Answers.Clear();
            foreach (var o in options)
                Answers.Add(new Answer(o));
        }

        public override string Display()
        {
            var s = $"[Choose All] {Header} ({Marks} pts)\n{Body}\n";
            for (int i = 0; i < Answers.Count; i++)
            {
                s += $"{i + 1}) {Answers[i].Text}\n";
            }
            return s.TrimEnd();
        }

        public override object Clone()
        {
            var c = (MultipleChoiceQuestion)base.Clone();
            c.CorrectIndexes = (int[])CorrectIndexes.Clone();
            return c;
        }
    }
}
