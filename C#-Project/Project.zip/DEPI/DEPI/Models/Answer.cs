using System;

namespace DEPI.Models
{
    public class Answer : ICloneable
    {
        public string Text { get; set; }
        public bool IsCorrect { get; set; }

        public Answer(string text, bool isCorrect = false)
        {
            Text = text;
            IsCorrect = isCorrect;
        }

        public override string ToString()
        {
            return Text + (IsCorrect ? " [Correct]" : string.Empty);
        }

        public object Clone()
        {
            return new Answer(Text, IsCorrect);
        }

        public override bool Equals(object obj)
        {
            return obj is Answer a && Text == a.Text && IsCorrect == a.IsCorrect;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(Text, IsCorrect);
        }
    }
}
