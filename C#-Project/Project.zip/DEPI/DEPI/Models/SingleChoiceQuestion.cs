using System;

namespace DEPI.Models
{
    public class SingleChoiceQuestion : Question
    {
        public int CorrectIndex { get; set; } = -1;

        public SingleChoiceQuestion(string header, string body, int marks) : base(header, body, marks)
        {
        }

        public void SetOptions(params string[] options)
        {
            Answers.Clear();
            for (int i = 0; i < options.Length; i++)
            {
                Answers.Add(new Answer(options[i]));
            }
        }

        public override string Display()
        {
            var s = $"[Choose One] {Header} ({Marks} pts)\n{Body}\n";
            for (int i = 0; i < Answers.Count; i++)
            {
                s += $"{i + 1}) {Answers[i].Text}\n";
            }
            return s.TrimEnd();
        }

        public override object Clone()
        {
            var c = (SingleChoiceQuestion)base.Clone();
            c.CorrectIndex = CorrectIndex;
            return c;
        }
    }
}
