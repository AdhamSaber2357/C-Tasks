using System;

namespace DEPI.Models
{
    public class TrueFalseQuestion : Question
    {
        public bool CorrectAnswer { get; set; }

        public TrueFalseQuestion(string header, string body, int marks, bool correctAnswer)
            : base(header, body, marks)
        {
            CorrectAnswer = correctAnswer;
            Answers.Add(new Answer("True"));
            Answers.Add(new Answer("False"));
        }

        public override string Display()
        {
            return $"[True/False] {Header} ({Marks} pts)\n{Body}\n1) True\n2) False";
        }

        public override object Clone()
        {
            var c = (TrueFalseQuestion)base.Clone();
            c.CorrectAnswer = CorrectAnswer;
            return c;
        }
    }
}
