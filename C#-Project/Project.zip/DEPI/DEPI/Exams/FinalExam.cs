using System;
using System.Collections.Generic;
using DEPI.Models;
using DEPI.Subjects;
using DEPI.Students;

namespace DEPI.Exams
{
    public class FinalExam : Exam
    {
        public List<Student> EnrolledStudents { get; } = new List<Student>();

        public FinalExam(Subject s) : base(s) { }

        public FinalExam(Subject s, TimeSpan duration) : base(s, duration) { }

        public void Enroll(Student student)
        {
            EnrolledStudents.Add(student);
            // subscribe to event
            ExamStarted += student.OnExamStarted;
        }

        public override void ShowExam()
        {
            Console.WriteLine("--- Final Exam ---");
            Console.WriteLine(this);
            foreach (var qa in QuestionAnswerKey)
            {
                Console.WriteLine(qa.Key.Display());
                // Final exam: do NOT show correct answers here
                Console.WriteLine();
            }
        }
    }
}
