using System;
using System.Collections.Generic;
using DEPI.Models;
using DEPI.Subjects;
using DEPI.Students;

namespace DEPI.Exams
{
    public class PracticeExam : Exam
    {
        public List<Student> EnrolledStudents { get; } = new List<Student>();

        public PracticeExam(Subject s) : base(s) { }

        public PracticeExam(Subject s, TimeSpan duration) : base(s, duration) { }

        public void Enroll(Student student)
        {
            EnrolledStudents.Add(student);
            // subscribe to event
            ExamStarted += student.OnExamStarted;
        }

        public override void ShowExam()
        {
            Console.WriteLine("--- Practice Exam ---");
            Console.WriteLine(this);
            foreach (var qa in QuestionAnswerKey)
            {
                Console.WriteLine(qa.Key.Display());
                // For practice exam, show correct answers after taking
                Console.WriteLine("Correct answers:");
                Console.WriteLine(qa.Value);
                Console.WriteLine();
            }
        }
    }
}
