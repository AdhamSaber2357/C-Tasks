using System;
using System.Collections.Generic;
using DEPI.Models;
using DEPI.Subjects;
using DEPI.Students;

namespace DEPI.Exams
{
    public enum ExamMode { Starting, Queued, Finished }

    public abstract class Exam : ICloneable, IComparable<Exam>
    {
        public TimeSpan Duration { get; set; }
        public int NumberOfQuestions { get; set; }
        public Dictionary<Question, AnswerList> QuestionAnswerKey { get; set; }
        public Subject Subject { get; set; }
        public ExamMode Mode { get; private set; }

        // Event to notify students when exam starts
        public event EventHandler<ExamStartedEventArgs> ExamStarted;

        protected Exam(Subject subject) : this(subject, TimeSpan.FromMinutes(60)) { }

        protected Exam(Subject subject, TimeSpan duration)
        {
            Subject = subject;
            Duration = duration;
            QuestionAnswerKey = new Dictionary<Question, AnswerList>();
            NumberOfQuestions = 0;
            Mode = ExamMode.Queued;
        }

        public void Start()
        {
            Mode = ExamMode.Starting;
            OnExamStarted(new ExamStartedEventArgs(Subject.ToString(), "Exam is starting now"));
        }

        public void Finish()
        {
            Mode = ExamMode.Finished;
        }

        protected virtual void OnExamStarted(ExamStartedEventArgs e)
        {
            ExamStarted?.Invoke(this, e);
        }

        public abstract void ShowExam();

        public override string ToString()
        {
            return $"Exam for {Subject} - {NumberOfQuestions} questions - Duration: {Duration}";
        }

        public virtual object Clone()
        {
            var clone = (Exam)MemberwiseClone();
            clone.QuestionAnswerKey = new Dictionary<Question, AnswerList>(QuestionAnswerKey);
            return clone;
        }

        public int CompareTo(Exam other)
        {
            if (other == null) return 1;
            return Duration.CompareTo(other.Duration);
        }

        public override bool Equals(object obj)
        {
            return obj is Exam e && Subject.Equals(e.Subject) && Duration.Equals(e.Duration);
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(Subject, Duration);
        }
    }
}
