﻿using System;
using DEPI.Models;
using DEPI.Collections;
using DEPI.Exams;
using DEPI.Subjects;
using DEPI.Students;

namespace DEPI
{
    class Program
    {
        static void Main(string[] args)
        {
            // Prepare a subject
            var subj = new Subject("MATH101", "Introduction to Programming");

            // Create a question list with its own log file
            var qlist = new QuestionList("Logs/math101_questions.log");

            // Create some questions
            var q1 = new TrueFalseQuestion("T1", "2+2=4?", 1, true);
            var q2 = new SingleChoiceQuestion("S1", "What is 3+2?", 2);
            q2.SetOptions("4", "5", "6");
            q2.CorrectIndex = 2; // option 2 -> "5"
            var q3 = new MultipleChoiceQuestion("M1", "Select primes", 3);
            q3.SetOptions("2", "3", "4", "5");
            q3.CorrectIndexes = new int[] { 0, 1, 3 };

            // Add to list (this will log each question to the file)
            qlist.Add(q1);
            qlist.Add(q2);
            qlist.Add(q3);

            // Create Practice and Final exams
            var practice = new PracticeExam(subj);
            var finalExam = new FinalExam(subj);

            // Populate question-answer keys
            practice.QuestionAnswerKey[q1] = new AnswerList { new Answer("True", true), new Answer("False") };
            practice.QuestionAnswerKey[q2] = new AnswerList { new Answer("4"), new Answer("5", true), new Answer("6") };
            practice.QuestionAnswerKey[q3] = new AnswerList { new Answer("2", true), new Answer("3", true), new Answer("4"), new Answer("5", true) };

            // Final uses same key but will not display answers
            finalExam.QuestionAnswerKey = practice.QuestionAnswerKey;

            // Enroll some students and subscribe to notifications
            var s1 = new Student("S001", "Alice");
            var s2 = new Student("S002", "Bob");
            practice.Enroll(s1);
            practice.Enroll(s2);
            finalExam.Enroll(s1);
            finalExam.Enroll(s2);

            Console.WriteLine("Select exam type to take:");
            Console.WriteLine("1) Practice Exam");
            Console.WriteLine("2) Final Exam");
            Console.Write("Choice: ");
            var key = Console.ReadLine();

            if (key == "1")
            {
                practice.Start();
                practice.ShowExam();
                practice.Finish();
            }
            else if (key == "2")
            {
                finalExam.Start();
                finalExam.ShowExam();
                finalExam.Finish();
            }
            else
            {
                Console.WriteLine("Invalid choice");
            }

            Console.WriteLine("Done.");
        }
    }
}
