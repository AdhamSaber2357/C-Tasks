using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using DEPI.Models;

namespace DEPI.Collections
{
    public class QuestionList : List<Question>
    {
        public string LogFilePath { get; }

        public QuestionList(string logFilePath)
        {
            if (string.IsNullOrWhiteSpace(logFilePath)) throw new ArgumentException("logFilePath required", nameof(logFilePath));
            LogFilePath = logFilePath;
            // ensure directory exists
            var dir = Path.GetDirectoryName(LogFilePath);
            if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir))
                Directory.CreateDirectory(dir);
        }

        // Keep default behavior but add logging
        public new void Add(Question item)
        {
            base.Add(item);
            LogQuestion(item);
        }

        private void LogQuestion(Question q)
        {
            // Append textual representation to the file
            using (var sw = new StreamWriter(LogFilePath, append: true, encoding: Encoding.UTF8))
            {
                sw.WriteLine("----- Question Logged: " + DateTime.UtcNow.ToString("o") + " -----");
                sw.WriteLine(q.ToString());
                sw.WriteLine();
            }
        }

        public IEnumerable<Question> ReadLoggedQuestions()
        {
            if (!File.Exists(LogFilePath)) yield break;
            using (var sr = new StreamReader(LogFilePath))
            {
                string line;
                var buffer = new List<string>();
                while ((line = sr.ReadLine()) != null)
                {
                    buffer.Add(line);
                }
            }
        }
    }
}
