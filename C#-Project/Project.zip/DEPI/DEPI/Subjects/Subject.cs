using System;

namespace DEPI.Subjects
{
    public class Subject
    {
        public string Code { get; set; }
        public string Name { get; set; }

        public Subject(string code, string name)
        {
            Code = code;
            Name = name;
        }

        public override string ToString()
        {
            return $"{Code} - {Name}";
        }
    }
}
