using System;

namespace DEPI.Students
{
    public class Student
    {
        public string Id { get; }
        public string Name { get; }

        public Student(string id, string name)
        {
            Id = id;
            Name = name;
        }

        public void OnExamStarted(object sender, ExamStartedEventArgs e)
        {
            Console.WriteLine($"[Notification] Student {Name} received exam start for subject {e.Subject}: {e.Message}");
        }

        public override string ToString() => $"{Name} ({Id})";
    }

    public class ExamStartedEventArgs : EventArgs
    {
        public string Message { get; set; }
        public string Subject { get; set; }

        public ExamStartedEventArgs(string subject, string message)
        {
            Subject = subject;
            Message = message;
        }
    }
}
