using System.Collections.Generic;

namespace DEPI.Models
{
    public class Product
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public decimal Price { get; set; }

        // Foreign key
        public int CategoryId { get; set; }
        public Category Category { get; set; }

        // Navigation for many-to-many via OrderDetail
        public ICollection<OrderDetail> OrderDetails { get; set; } = new List<OrderDetail>();
    }
}