using System;
using System.Collections.Generic;

namespace DEPI.Models
{
    public class Order
    {
        public int Id { get; set; }
        public DateTime OrderDate { get; set; }

        // Foreign key
        public int CustomerId { get; set; }
        public Customer Customer { get; set; }

        // Navigation for many-to-many via OrderDetail
        public ICollection<OrderDetail> OrderDetails { get; set; } = new List<OrderDetail>();
    }
}