using System;

namespace DEPI.Library.Models
{
    public class Loan
    {
        // Composite key: BookId + BorrowerId + LoanDate (optional)
        public int BookId { get; set; }
        public Book Book { get; set; }

        public int BorrowerId { get; set; }
        public Borrower Borrower { get; set; }

        public DateTime LoanDate { get; set; }
        public DateTime? ReturnDate { get; set; }
    }
}