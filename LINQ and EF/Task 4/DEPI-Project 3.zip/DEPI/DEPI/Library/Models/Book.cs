using System.Collections.Generic;

namespace DEPI.Library.Models
{
    public class Book
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string ISBN { get; set; }

        // Foreign key
        public int AuthorId { get; set; }
        public Author Author { get; set; }

        // Navigation for many-to-many via Loan
        public ICollection<Loan> Loans { get; set; } = new List<Loan>();
    }
}