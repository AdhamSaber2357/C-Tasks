using System;
using System.Collections.Generic;

namespace DEPI.Library.Models
{
    public class Borrower
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public DateTime MembershipDate { get; set; }

        // Navigation
        public ICollection<Loan> Loans { get; set; } = new List<Loan>();
    }
}