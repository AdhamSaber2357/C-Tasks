﻿using DEPI;
using System;
using System.Collections.Generic;
using System.Linq;


namespace DEPI
{
    class Program
    {
        static void Main(string[] args)
        {

        }
    }

}
