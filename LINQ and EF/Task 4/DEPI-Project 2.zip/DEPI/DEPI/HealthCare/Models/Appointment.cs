using System;

namespace DEPI.HealthCare.Models
{
    public class Appointment
    {
        // Composite key: PatientId + DoctorId + AppointmentDate
        public int PatientId { get; set; }
        public Patient Patient { get; set; }

        public int DoctorId { get; set; }
        public Doctor Doctor { get; set; }

        public DateTime AppointmentDate { get; set; }
    }
}