using System;
using System.Collections.Generic;
using System.Linq;

namespace DEPI.Utilities
{
    public static class DelegatesAndUtils
    {
        public static T GetDefault<T>() => default;

        public static List<R> TransformList<T, R>(IEnumerable<T> items, Func<T, R> transformer)
        {
            return items.Select(transformer).ToList();
        }

        public static List<string> ApplyStringFunc(IEnumerable<string> inputs, Func<string, string> func)
        {
            return inputs.Select(func).ToList();
        }

        public static int Operate(int a, int b, Func<int, int, int> op) => op(a, b);

        public static void ApplyAction(IEnumerable<string> inputs, Action<string> action)
        {
            foreach (var s in inputs) action(s);
        }

        public static List<T> Filter<T>(IEnumerable<T> inputs, Predicate<T> predicate)
        {
            var list = new List<T>();
            foreach (var item in inputs)
                if (predicate(item)) list.Add(item);
            return list;
        }
    }
}
