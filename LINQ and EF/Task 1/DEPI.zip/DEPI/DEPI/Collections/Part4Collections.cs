using System;
using System.Collections;
using System.Collections.Generic;
using DEPI.Models;

namespace DEPI.Collections
{
    public static class Part4Collections
    {
        public static void Run()
        {
            #region Problem09 - List basics
            Console.WriteLine("\nProblem09: List basics (add, remove, search using loop)");
            var names = new List<string>();
            names.Add("Ahmed");
            names.Add("Sara");
            names.Add("Mona");
            names.Add("Omar");

            // Remove an item
            names.Remove("Mona");

            // Search for a name using a loop (no LINQ)
            string search = "Sara";
            bool found = false;
            for (int i = 0; i < names.Count; i++)
            {
                if (names[i] == search)
                {
                    found = true;
                    break;
                }
            }

            Console.WriteLine($"Found '{search}': {found}");
            Console.WriteLine("Final list:");
            foreach (var n in names) Console.WriteLine(n);
            #endregion

            #region Problem10 - List of custom objects
            Console.WriteLine("\nProblem10: List<Employee> and print those with salary above threshold");
            var staff = new List<Employee>
            {
                new Employee(1, "Lina", 3500m),
                new Employee(2, "Hassan", 4200m),
                new Employee(3, "Nadia", 2800m)
            };

            decimal threshold = 3000m;
            Console.WriteLine($"Employees with salary above {threshold}:");
            for (int i = 0; i < staff.Count; i++)
            {
                if (staff[i].Salary > threshold)
                    Console.WriteLine(staff[i]);
            }
            #endregion

            #region Problem11 - Dictionary basics
            Console.WriteLine("\nProblem11: Dictionary<string,int> mapping product names to prices");
            var products = new Dictionary<string, int>();
            products["Pen"] = 5;
            products["Notebook"] = 20;
            products.Add("Eraser", 3);

            Console.WriteLine("Product list (key => value):");
            foreach (var kv in products)
            {
                Console.WriteLine($"{kv.Key} => {kv.Value}");
            }
            #endregion

            #region Problem12 - Dictionary lookup (ask user for ID and print name)
            Console.WriteLine("\nProblem12: Dictionary<int,string> lookup by student ID (TryGetValue)");
            var students = new Dictionary<int, string>
            {
                { 1001, "Amira" },
                { 1002, "Khaled" },
                { 1003, "Yara" }
            };

            Console.Write("Enter student ID to lookup (e.g. 1002): ");
            var input = Console.ReadLine();
            if (int.TryParse(input, out int id))
            {
                if (students.TryGetValue(id, out string studentName))
                    Console.WriteLine($"ID {id} => {studentName}");
                else
                    Console.WriteLine($"ID {id} not found.");
            }
            else
            {
                Console.WriteLine("Invalid input. Skipping lookup demo.");
            }
            #endregion

            #region Problem13 - Hashtable basics
            Console.WriteLine("\nProblem13: Hashtable basics with mixed key/value types");
            var table = new Hashtable();
            table[1] = "One";
            table["two"] = 2;
            table[3] = "Three";

            Console.WriteLine("Hashtable entries:");
            foreach (DictionaryEntry entry in table)
            {
                Console.WriteLine($"Key={entry.Key}, Value={entry.Value}");
            }
            #endregion

            #region Problem14 - Dictionary vs Hashtable
            Console.WriteLine("\nProblem14: Dictionary<string,string> vs Hashtable");
            var dict = new Dictionary<string, string>
            {
                { "a", "alpha" },
                { "b", "beta" }
            };

            var ht = new Hashtable();
            ht["a"] = "alpha";
            ht["b"] = "beta";

            Console.WriteLine("Dictionary entries (typed):");
            foreach (var kv in dict)
            {
                Console.WriteLine($"{kv.Key} => {kv.Value}");
            }

            Console.WriteLine("Hashtable entries (non-generic, untyped access):");
            foreach (DictionaryEntry de in ht)
            {
                Console.WriteLine($"{de.Key} => {de.Value}");
            }

            Console.WriteLine("Note: Dictionary<TKey,TValue> is generic and provides typed access, while Hashtable stores objects and requires casting.");
            #endregion
        }
    }
}
