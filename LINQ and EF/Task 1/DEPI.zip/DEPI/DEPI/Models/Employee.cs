using System;

namespace DEPI.Models
{
    public class Employee : ICloneable, IComparable<Employee>
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public decimal Salary { get; set; }

        public Employee() { }

        public Employee(int id, string name, decimal salary)
        {
            Id = id;
            Name = name;
            Salary = salary;
        }

        public object Clone()
        {
            return new Employee(Id, Name, Salary);
        }

        public int CompareTo(Employee other)
        {
            if (other == null) return 1;
            return Salary.CompareTo(other.Salary);
        }

        public override string ToString()
        {
            return $"Employee(Id={Id}, Name={Name}, Salary={Salary})";
        }
    }
}
