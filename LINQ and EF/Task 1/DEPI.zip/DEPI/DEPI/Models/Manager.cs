using System;

namespace DEPI.Models
{
    public class Manager : Employee, IComparable<Manager>
    {
        public string Department { get; set; }

        public Manager() { }

        public Manager(int id, string name, decimal salary, string department = null) : base(id, name, salary)
        {
            Department = department;
        }

        public int CompareTo(Manager other)
        {
            if (other == null) return 1;
            return Salary.CompareTo(other.Salary);
        }

        public override string ToString()
        {
            return $"Manager(Id={Id}, Name={Name}, Salary={Salary}, Dept={Department})";
        }
    }
}
