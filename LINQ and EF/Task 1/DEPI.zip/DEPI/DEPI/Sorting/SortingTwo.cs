using System;

namespace DEPI.Sorting
{
    public static class SortingTwo<T>
    {
        public static void Sort(T[] array, Func<T, T, bool> comesBefore)
        {
            if (array == null) throw new ArgumentNullException(nameof(array));
            if (comesBefore == null) throw new ArgumentNullException(nameof(comesBefore));

            int n = array.Length;
            for (int i = 0; i < n - 1; i++)
            {
                for (int j = 0; j < n - 1 - i; j++)
                {
                    if (!comesBefore(array[j], array[j + 1]))
                    {
                        var tmp = array[j];
                        array[j] = array[j + 1];
                        array[j + 1] = tmp;
                    }
                }
            }
        }
    }
}
