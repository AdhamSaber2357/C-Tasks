using System;

namespace DEPI.Sorting
{
    public static class SortingAlgorithm<T> where T : ICloneable
    {
        public static void Sort(T[] array, Comparison<T> comparer)
        {
            if (array == null) throw new ArgumentNullException(nameof(array));
            if (comparer == null) throw new ArgumentNullException(nameof(comparer));

            int n = array.Length;
            for (int i = 0; i < n - 1; i++)
            {
                int min = i;
                for (int j = i + 1; j < n; j++)
                {
                    if (comparer(array[j], array[min]) < 0) min = j;
                }

                if (min != i) Swap(array, i, min);
            }
        }

        public static void Swap<U>(U[] array, int i, int j)
        {
            if (array == null) throw new ArgumentNullException(nameof(array));
            U tmp = array[i];
            array[i] = array[j];
            array[j] = tmp;
        }
    }
}
