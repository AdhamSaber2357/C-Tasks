﻿using System;
using System.Collections.Generic;
using System.Linq;
using DEPI.Collections;

namespace DEPI
{
    class Program
    {
        static void Main(string[] args)
        {
            Part4Collections.Run();
        }
    }

}
