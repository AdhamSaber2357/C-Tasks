﻿using DEPI.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DEPI.Configuration
{
    public class AuthorConfiguration : IEntityTypeConfiguration<Author>
    {
        public void Configure(EntityTypeBuilder<Author> A)
        {
           A.HasKey(x => x.Id);
           A.Property(x => x.Id)
            .UseIdentityColumn(10,10);

            A.Property(x => x.Name)
             .IsRequired(true)
             .HasColumnType("varchar")
             .HasColumnName("authorName")
             .HasDefaultValue("nono")
             .HasMaxLength(50);
        }
    }
}
