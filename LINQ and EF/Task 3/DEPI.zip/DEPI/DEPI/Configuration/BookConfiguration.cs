﻿using DEPI.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DEPI.Configuration
{
    internal class BookConfiguration : IEntityTypeConfiguration<Book>
    {
        public void Configure(EntityTypeBuilder<Book> A)
        {
            A.HasKey(x => x.Id);
            A.Property(x => x.Id)
             .UseIdentityColumn(10, 10);

            A.Property(x => x.Title)
             .IsRequired(true)
             .HasColumnType("varchar")
             .HasColumnName("bookName")
             .HasDefaultValue("bobo")
             .HasMaxLength(50);
        }
    }
}
