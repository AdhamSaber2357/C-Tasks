using System;
using System.ComponentModel.DataAnnotations;

namespace DEPI.Models
{
    public class Book
    {
        [Key]
        public int Id { get; set; }


        [Required]
        [MaxLength(150)]
        public string Title { get; set; }

        [Required]
        public decimal Price { get; set; }

        public DateTime? PublishedDate { get; set; }
    }
}
