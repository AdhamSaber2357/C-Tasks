using System.ComponentModel.DataAnnotations;

namespace DEPI.Models
{
    public class Author
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [MaxLength(100)]
        public string Name { get; set; }

        public string? Country { get; set; }
    }
}
