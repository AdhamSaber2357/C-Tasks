﻿using DEPI;
using System;
using System.Collections.Generic;
using System.Linq;
using static DEPI.ListGenerators;


namespace DEPI
{
    class Program
    {
        static void Main(string[] args)
        {

            LinqExercises.RunAll();            
        }
    }

}
