using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace DEPI
{
    public static class LinqExercises
    {
        public static void RunAll()
        {
            Console.WriteLine("--- LINQ Exercises ---");

            #region Restriction Operators
            Console.WriteLine("\nRestriction Operators:");
            // 1. Find all products that are out of stock.
            Console.WriteLine("1) Products out of stock:");
            var outOfStock = ListGenerators.ProductList.Where(p => p.UnitsInStock == 0);
            foreach (var p in outOfStock) Console.WriteLine(p.ProductName);

            // 2. Find all products that are in stock and cost more than 3.00 per unit.
            Console.WriteLine("2) In stock and UnitPrice > 3.00:");
            var expensiveInStock = ListGenerators.ProductList.Where(p => p.UnitsInStock > 0 && p.UnitPrice > 3.00M);
            foreach (var p in expensiveInStock) Console.WriteLine(p.ProductName + " - " + p.UnitPrice);

            // 3. Returns digits whose name is shorter than their value.
            Console.WriteLine("3) Digits whose name length < value:");
            string[] digits = { "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine" };
            var shortNameDigits = digits.Where((name, index) => name.Length < index);
            foreach (var d in shortNameDigits) Console.WriteLine(d);
            #endregion

            #region Element Operators
            Console.WriteLine("\nElement Operators:");
            // 1. Get first Product out of Stock
            Console.WriteLine("1) First product out of stock:");
            var firstOut = ListGenerators.ProductList.FirstOrDefault(p => p.UnitsInStock == 0);
            Console.WriteLine(firstOut?.ProductName ?? "None");

            // 2. Return the first product whose Price > 1000, unless none then null
            Console.WriteLine("2) First product with price > 1000 (or null):");
            var pricey = ListGenerators.ProductList.FirstOrDefault(p => p.UnitPrice > 1000m);
            Console.WriteLine(pricey?.ProductName ?? "null");

            // 3. Retrieve the second number greater than 5
            Console.WriteLine("3) Second number > 5:");
            int[] arrNums = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };
            var secondGreater5 = arrNums.Where(n => n > 5).Skip(1).FirstOrDefault();
            Console.WriteLine(secondGreater5);
            #endregion

            #region Aggregate Operators
            Console.WriteLine("\nAggregate Operators:");
            // 1. Count odd numbers
            Console.WriteLine("1) Count odd numbers:");
            int[] arrAgg = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };
            Console.WriteLine(arrAgg.Count(n => n % 2 != 0));

            // 2. Return a list of customers and how many orders each has.
            Console.WriteLine("2) Customers and number of orders:");
            EnsureSampleCustomers();
            var customerOrderCounts = ListGenerators.CustomerList.Select(c => new { c.Name, OrderCount = (c.Orders?.Length ?? 0) });
            foreach (var c in customerOrderCounts) Console.WriteLine($"{c.Name}: {c.OrderCount}");

            // 3. Return a list of categories and how many products each has
            Console.WriteLine("3) Categories and product counts:");
            var catCounts = ListGenerators.ProductList.GroupBy(p => p.Category).Select(g => new { Category = g.Key, Count = g.Count() });
            foreach (var g in catCounts) Console.WriteLine($"{g.Category}: {g.Count}");

            // 4. Get the total of the numbers in an array
            Console.WriteLine("4) Sum of numbers:");
            Console.WriteLine(arrAgg.Sum());

            // 5. Total number of characters of all words in dictionary_english.txt
            Console.WriteLine("5) Total chars in dictionary_english.txt (or fallback):");
            var words = ReadDictionary();
            Console.WriteLine(words.Sum(w => w.Length));

            // 6. Total units in stock for each product category
            Console.WriteLine("6) Total units in stock per category:");
            var unitsPerCat = ListGenerators.ProductList.GroupBy(p => p.Category).Select(g => new { Category = g.Key, Units = g.Sum(p => p.UnitsInStock) });
            foreach (var u in unitsPerCat) Console.WriteLine($"{u.Category}: {u.Units}");

            // 7. Length of shortest word in dictionary
            Console.WriteLine("7) Shortest word length in dictionary:");
            Console.WriteLine(words.Min(w => w.Length));

            // 8. Cheapest price among each category's products
            Console.WriteLine("8) Cheapest price per category:");
            var cheapestPerCat = ListGenerators.ProductList.GroupBy(p => p.Category).Select(g => new { Category = g.Key, MinPrice = g.Min(p => p.UnitPrice) });
            foreach (var c in cheapestPerCat) Console.WriteLine($"{c.Category}: {c.MinPrice}");

            // 9. Products with the cheapest price in each category
            Console.WriteLine("9) Products with cheapest price per category:");
            var cheapestProducts = ListGenerators.ProductList.GroupBy(p => p.Category)
                .Select(g => new { Category = g.Key, MinPrice = g.Min(p => p.UnitPrice), Items = g.Where(p => p.UnitPrice == g.Min(x => x.UnitPrice)) });
            foreach (var grp in cheapestProducts)
            {
                Console.WriteLine(grp.Category + ":");
                foreach (var item in grp.Items) Console.WriteLine("  " + item.ProductName + " - " + item.UnitPrice);
            }

            // 10. Length of longest word in dictionary
            Console.WriteLine("10) Longest word length in dictionary:");
            Console.WriteLine(words.Max(w => w.Length));

            // 11. Most expensive price among each category's products
            Console.WriteLine("11) Most expensive price per category:");
            var maxPerCat = ListGenerators.ProductList.GroupBy(p => p.Category).Select(g => new { Category = g.Key, MaxPrice = g.Max(p => p.UnitPrice) });
            foreach (var c in maxPerCat) Console.WriteLine($"{c.Category}: {c.MaxPrice}");

            // 12. Products with the most expensive price in each category
            Console.WriteLine("12) Products with most expensive price per category:");
            var mostExpensiveProducts = ListGenerators.ProductList.GroupBy(p => p.Category)
                .Select(g => new { Category = g.Key, MaxPrice = g.Max(p => p.UnitPrice), Items = g.Where(p => p.UnitPrice == g.Max(x => x.UnitPrice)) });
            foreach (var grp in mostExpensiveProducts)
            {
                Console.WriteLine(grp.Category + ":");
                foreach (var item in grp.Items) Console.WriteLine("  " + item.ProductName + " - " + item.UnitPrice);
            }

            // 13. Average length of the words in dictionary
            Console.WriteLine("13) Average word length in dictionary:");
            Console.WriteLine(words.Average(w => w.Length));

            // 14. Average price of each category's products
            Console.WriteLine("14) Average price per category:");
            var avgPerCat = ListGenerators.ProductList.GroupBy(p => p.Category).Select(g => new { Category = g.Key, AvgPrice = g.Average(p => p.UnitPrice) });
            foreach (var c in avgPerCat) Console.WriteLine($"{c.Category}: {c.AvgPrice:F2}");
            #endregion

            #region Ordering Operators
            Console.WriteLine("\nOrdering Operators:");
            // 1. Sort a list of products by name
            Console.WriteLine("1) Products sorted by name:");
            var byName = ListGenerators.ProductList.OrderBy(p => p.ProductName);
            foreach (var p in byName) Console.WriteLine(p.ProductName);

            // 2. case-insensitive sort of words
            Console.WriteLine("2) Case-insensitive sort:");
            string[] arr2 = { "aPPLE", "AbAcUs", "bRaNcH", "BlUeBeRrY", "ClOvEr", "cHeRry" };
            var ci = arr2.OrderBy(s => s, StringComparer.OrdinalIgnoreCase);
            foreach (var s in ci) Console.WriteLine(s);

            // 3. Sort products by units in stock from highest to lowest
            Console.WriteLine("3) Products by units in stock (desc):");
            var byUnits = ListGenerators.ProductList.OrderByDescending(p => p.UnitsInStock);
            foreach (var p in byUnits.Take(10)) Console.WriteLine(p.ProductName + " - " + p.UnitsInStock);

            // 4. Sort digits first by length then alphabetically
            Console.WriteLine("4) Digits sorted by length then name:");
            var digitsSorted = digits.OrderBy(s => s.Length).ThenBy(s => s);
            foreach (var d in digitsSorted) Console.WriteLine(d);

            // 5. Sort first by word length then case-insensitive
            Console.WriteLine("5) Words sorted by length then case-insensitive:");
            var wordsArr = arr2.OrderBy(s => s.Length).ThenBy(s => s, StringComparer.OrdinalIgnoreCase);
            foreach (var w in wordsArr) Console.WriteLine(w);

            // 6. Sort products first by category then by unit price desc
            Console.WriteLine("6) Products by category then unit price desc:");
            var byCatPrice = ListGenerators.ProductList.OrderBy(p => p.Category).ThenByDescending(p => p.UnitPrice);
            foreach (var p in byCatPrice.Take(10)) Console.WriteLine(p.Category + " - " + p.ProductName + " - " + p.UnitPrice);

            // 7. Sort by length then case-insensitive descending
            Console.WriteLine("7) Words sorted by length then case-insensitive desc:");
            var words7 = arr2.OrderBy(s => s.Length).ThenByDescending(s => s, StringComparer.OrdinalIgnoreCase);
            foreach (var w in words7) Console.WriteLine(w);

            // 8. digits whose second letter is 'i' reversed from original order
            Console.WriteLine("8) Digits with second letter 'i' reversed from original array:");
            var digitsWithI = digits.Where(s => s.Length >= 2 && s[1] == 'i').Reverse();
            foreach (var d in digitsWithI) Console.WriteLine(d);
            #endregion

            #region Transformation Operators
            Console.WriteLine("\nTransformation Operators:");
            // 1. sequence of just the names of products
            Console.WriteLine("1) Product names:");
            var names = ListGenerators.ProductList.Select(p => p.ProductName);
            foreach (var n in names.Take(10)) Console.WriteLine(n);

            // 2. uppercase and lowercase versions (anonymous types)
            Console.WriteLine("2) Uppercase and lowercase anonymous types:");
            var wordList = new[] { "aPPLE", "BlUeBeRrY", "cHeRry" };
            var cases = wordList.Select(w => new { Upper = w.ToUpper(), Lower = w.ToLower() });
            foreach (var c in cases) Console.WriteLine($"{c.Upper} / {c.Lower}");

            // 3. select some properties, rename UnitPrice to Price
            Console.WriteLine("3) Select product properties including Price:");
            var proj = ListGenerators.ProductList.Select(p => new { p.ProductName, Price = p.UnitPrice, p.Category });
            foreach (var x in proj.Take(10)) Console.WriteLine($"{x.ProductName} - {x.Price} - {x.Category}");

            // 4. Determine if value matches position
            Console.WriteLine("4) Number: In-place? :");
            var placeCheck = arrAgg.Select((num, index) => new { Number = num, InPlace = num == index });
            foreach (var it in placeCheck) Console.WriteLine($"{it.Number}: {it.InPlace}");

            // 5. All pairs where a < b
            Console.WriteLine("5) Pairs where a < b:");
            int[] numbersA = { 0, 2, 4, 5, 6, 8, 9 };
            int[] numbersB = { 1, 3, 5, 7, 8 };
            var pairs = from a in numbersA from b in numbersB where a < b select new { a, b };
            foreach (var p in pairs) Console.WriteLine($"{p.a} is less than {p.b}");

            // 6. Select all orders where order total < 500
            Console.WriteLine("6) Orders with total < 500:");
            EnsureSampleCustomers();
            var smallOrders = ListGenerators.CustomerList.SelectMany(c => c.Orders ?? new Order[0]).Where(o => o != null && o.Total < 500);
            foreach (var o in smallOrders) Console.WriteLine(o);

            // 7. Select all orders where order was made in 1998 or later
            Console.WriteLine("7) Orders from 1998 or later:");
            var recentOrders = ListGenerators.CustomerList.SelectMany(c => c.Orders ?? new Order[0]).Where(o => o != null && o.OrderDate.Year >= 1998);
            foreach (var o in recentOrders) Console.WriteLine(o);
            #endregion

            #region Partitioning Operators
            Console.WriteLine("\nPartitioning Operators:");
            // 1. Get the first 3 orders from customers in Washington
            Console.WriteLine("1) First 3 orders from customers in Washington:");
            var waOrders = ListGenerators.CustomerList.Where(c => c.City == "Washington").SelectMany(c => c.Orders ?? new Order[0]).Take(3);
            foreach (var o in waOrders) Console.WriteLine(o);

            // 2. Get all but the first 2 orders from customers in Washington
            Console.WriteLine("2) All but first 2 orders from Washington customers:");
            var skip2 = ListGenerators.CustomerList.Where(c => c.City == "Washington").SelectMany(c => c.Orders ?? new Order[0]).Skip(2);
            foreach (var o in skip2) Console.WriteLine(o);

            // 3. Return elements starting from the beginning until a number is hit that is less than its position
            Console.WriteLine("3) TakeWhile number >= index:");
            var takeUntil = arrAgg.TakeWhile((num, index) => num >= index);
            Console.WriteLine(string.Join(",", takeUntil));

            // 4. Get elements starting from first element divisible by 3
            Console.WriteLine("4) Elements starting from first divisible by 3:");
            var startDiv3 = arrAgg.SkipWhile(n => n % 3 != 0);
            Console.WriteLine(string.Join(",", startDiv3));

            // 5. Elements starting from first element less than its position
            Console.WriteLine("5) Elements starting from first element less than its position:");
            var startLessPos = arrAgg.SkipWhile((num, index) => num >= index);
            Console.WriteLine(string.Join(",", startLessPos));
            #endregion

            #region Quantifiers
            Console.WriteLine("\nQuantifiers:");
            // 1. Determine if any words contain 'ei'
            Console.WriteLine("1) Any word contains 'ei'?");
            Console.WriteLine(words.Any(w => w.Contains("ei")));

            // 2. grouped list of products only for categories that have at least one product out of stock
            Console.WriteLine("2) Categories with at least one product out of stock:");
            var groupsWithSomeOut = ListGenerators.ProductList.GroupBy(p => p.Category).Where(g => g.Any(p => p.UnitsInStock == 0));
            foreach (var g in groupsWithSomeOut)
            {
                Console.WriteLine(g.Key + ":");
                foreach (var p in g) Console.WriteLine("  " + p.ProductName + " - " + p.UnitsInStock);
            }

            // 3. grouped list only for categories that have all of their products in stock
            Console.WriteLine("3) Categories where all products are in stock:");
            var groupsAllIn = ListGenerators.ProductList.GroupBy(p => p.Category).Where(g => g.All(p => p.UnitsInStock > 0));
            foreach (var g in groupsAllIn)
            {
                Console.WriteLine(g.Key + ":");
                foreach (var p in g) Console.WriteLine("  " + p.ProductName + " - " + p.UnitsInStock);
            }
            #endregion

            Console.WriteLine("\n--- LINQ Exercises Completed ---");
        }

        static string[] ReadDictionary()
        {
            var path = Path.Combine(AppContext.BaseDirectory, "dictionary_english.txt");
            if (File.Exists(path))
                return File.ReadAllLines(path);
            // fallback small sample
            return new[] { "apple", "banana", "cat", "dog", "elephant", "z" };
        }

        static void EnsureSampleCustomers()
        {
            if (ListGenerators.CustomerList != null && ListGenerators.CustomerList.Count > 0) return;
            var c1 = new Customer(1, "Alice") { City = "Washington", Orders = new Order[] { new Order(1, new DateTime(1999, 1, 1), 250), new Order(2, new DateTime(1997, 5, 4), 750) } };
            var c2 = new Customer(2, "Bob") { City = "Seattle", Orders = new Order[] { new Order(3, new DateTime(2000, 6, 6), 1200) } };
            var c3 = new Customer(3, "Carol") { City = "Washington", Orders = new Order[] { new Order(4, new DateTime(2001, 3, 3), 50), new Order(5, new DateTime(1998, 12, 12), 400) } };
            ListGenerators.CustomerList = new List<Customer> { c1, c2, c3 };
        }
    }
}
