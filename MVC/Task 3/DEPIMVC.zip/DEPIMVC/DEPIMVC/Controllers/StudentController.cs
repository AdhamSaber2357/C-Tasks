﻿using DEPIMVC.Models.Contexrs;
using DEPIMVC.Models.Entities;
using Microsoft.AspNetCore.Mvc;

namespace DEPIMVC.Controllers
{
    public class StudentController : Controller
    {
         AppDbContext context = new AppDbContext();
        public IActionResult Index()
        {
            var Students = context.Students.ToList();
            return View(Students);
        }

        public IActionResult GetStudentById(int id)
        {
            var Student = context.Students.FirstOrDefault(s=>s.Id==id);
            return View(Student);
        }
    }
}
