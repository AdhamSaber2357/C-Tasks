﻿using DEPIMVC.Models.Entities;

namespace DEPIMVC.ViewModels
{
    public class StudentVM
    {
        public int Id { get; set; }
        public int Age { get; set; }
        public int? DeptId { get; set; }
     
       public List<Department> Alldepartments { get; set; }
        public string Name { get; set; }
    }
}
