using System.ComponentModel.DataAnnotations;
using DEPIMVC.Models.Entities;

namespace DEPIMVC.ViewModels
{
    public class CourseVM : IValidatableObject
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Course name is required.")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Course name must be between 2 and 100 characters.")]
        public string Name { get; set; } = string.Empty;

        [Range(0, 100, ErrorMessage = "Degree must be between 0 and 100.")]
        public double Degree { get; set; }

        [Display(Name = "Minimum degree")]
        [Range(0, 100, ErrorMessage = "Minimum degree must be between 0 and 100.")]
        public double MinDegree { get; set; }

        [Display(Name = "Department")]
        [Range(1, int.MaxValue, ErrorMessage = "Please select a department.")]
        public int DeptId { get; set; }

        public List<Department> Departments { get; set; } = new();

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            if (MinDegree > Degree)
            {
                yield return new ValidationResult(
                    "Minimum degree cannot be greater than the degree.",
                    new[] { nameof(MinDegree), nameof(Degree) });
            }
        }
    }
}
