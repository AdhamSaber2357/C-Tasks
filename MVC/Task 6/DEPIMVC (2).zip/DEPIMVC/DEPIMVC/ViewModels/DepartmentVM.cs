﻿using DEPIMVC.Models.Entities;

namespace DEPIMVC.ViewModels
{
    public class DepartmentVM
    {
        public string Name { get; set; }
        public List<Student> students { get; set; }
        public string State { get; set; }

    }
}
