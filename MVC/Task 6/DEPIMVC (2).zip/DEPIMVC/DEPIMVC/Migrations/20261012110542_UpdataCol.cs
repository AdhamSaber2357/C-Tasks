﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DEPIMVC.Migrations
{
    /// <inheritdoc />
    public partial class UpdataCol : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
