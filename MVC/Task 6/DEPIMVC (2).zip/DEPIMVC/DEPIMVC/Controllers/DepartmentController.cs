﻿using DEPIMVC.Models.Contexrs;
using DEPIMVC.Models.Entities;
using DEPIMVC.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace DEPIMVC.Controllers
{
    public class DepartmentController : Controller
    {
        // Department/Index
        AppDbContext context = new AppDbContext();
        public IActionResult Index()
        {
            List<DepartmentVM> departmentVMs = new List<DepartmentVM>();
            var Departments = context.Departments.Include(d => d.students).ToList();
            foreach(var d in Departments)
            {
                var StudentsGreater20 =d.students.Where(s => s.Age>19).ToList() ;
                departmentVMs.Add(
                    
                    new DepartmentVM {
                        Name = d.Name, 
                        students = StudentsGreater20,
                        State = d.students.Count >2 ? "Main" : "Branch"
                    }
                    
                    );
            }
            return View(departmentVMs);
        }

        public IActionResult ShowDetails(int id)
        {
            var Department = context.Departments.Include(d=>d.students).FirstOrDefault(s => s.Id == id);
            var Departmentvm = new DepartmentVM { Name = Department.Name, students = Department.students };
            return View(Departmentvm);
        }

        public IActionResult Add()
        {
            return View();
        }
        [HttpPost]
        public IActionResult SaveAdd(Department department)
        {
            if (department.Name == null || department.MgrName == null)
                return View("Add", department);


            context.Add(department);
            context.SaveChanges();
            return RedirectToAction(nameof(Index));
        }


    }
}
