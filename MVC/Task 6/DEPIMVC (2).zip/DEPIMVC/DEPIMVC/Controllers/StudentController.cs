﻿using DEPIMVC.Models.Contexrs;
using DEPIMVC.Models.Entities;
using DEPIMVC.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace DEPIMVC.Controllers
{
    public class StudentController : Controller
    {
         AppDbContext context = new AppDbContext();
        public IActionResult Index()
        {
            var Students = context.Students.ToList();
            return View(Students);
        }

        public IActionResult GetStudentById(int id)
        {
            var Student = context.Students.FirstOrDefault(s=>s.Id==id);
            return View(Student);
        }

        public IActionResult Add()
        {
            var departments = context.Departments.ToList();
            var svm = new StudentVM { Alldepartments= departments };
            return View(svm);
        }
        [HttpPost]
        public IActionResult SaveAdd(StudentVM studentVM)
        {

            if(studentVM.Name == null ) 
                return View(nameof(Add),studentVM);

            var student = new Student { Name = studentVM.Name, Age = studentVM.Age , DeptId = studentVM.DeptId  };
            context.Students.Add(student);
            context.SaveChanges();
            
            return RedirectToAction(nameof(Index)); 
        }
        public IActionResult Update(int id)
        {
            var departments = context.Departments.ToList();
            var student = context.Students.FirstOrDefault(s=>s.Id == id);
            var svm = new StudentVM { Alldepartments = departments , Id = id, Age = student.Age , DeptId =student.DeptId, Name = student.Name };

            return View(svm);
        }
        
        public IActionResult SaveUpdate(StudentVM studentVM, int id)
        {

            if (studentVM.Name == null || studentVM.Age == 0 || studentVM.DeptId == 0)
                return View(nameof(Update), studentVM);

            var student = context.Students.FirstOrDefault(s => s.Id == id);
            student.Name = studentVM.Name;
            student.Age = studentVM.Age;
            student.DeptId = studentVM.DeptId;

            context.SaveChanges();

            return RedirectToAction(nameof(Index));


        }

        public IActionResult Delete(int id)
        {
            var student = context.Students.FirstOrDefault(s => s.Id == id);
            var svm = new StudentVM {  Id = id, Age = student.Age, DeptId = student.DeptId, Name = student.Name };

            return View(svm);
        }
        public IActionResult SaveDelete(int id)
        {


            var student = context.Students.FirstOrDefault(s => s.Id == id);

            if(student == null)
                return View(nameof(Delete));



            context.Students.Remove(student);
            context.SaveChanges();




            return RedirectToAction(nameof(Index));
        }
    }
}
