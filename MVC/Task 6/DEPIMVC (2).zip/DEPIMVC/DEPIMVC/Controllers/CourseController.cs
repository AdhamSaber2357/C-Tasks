using DEPIMVC.Models.Contexrs;
using DEPIMVC.Models.Entities;
using DEPIMVC.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace DEPIMVC.Controllers
{
    public class CourseController : Controller
    {
        private readonly AppDbContext context = new();

        public IActionResult Index()
        {
            var courses = context.Courses
                .Include(c => c.Dept)
                .AsNoTracking()
                .ToList();

            return View(courses);
        }

        [HttpGet]
        public IActionResult Add()
        {
            return View(new CourseVM { Departments = GetDepartments() });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult SaveAdd(CourseVM courseVM)
        {
            ValidateDepartment(courseVM.DeptId);

            if (!ModelState.IsValid)
            {
                courseVM.Departments = GetDepartments();
                return View(nameof(Add), courseVM);
            }

            var course = new Course
            {
                Name = courseVM.Name.Trim(),
                Degree = courseVM.Degree,
                minDegree = courseVM.MinDegree,
                DeptId = courseVM.DeptId
            };

            context.Courses.Add(course);
            context.SaveChanges();
            return RedirectToAction(nameof(Index));
        }

        [HttpGet]
        public IActionResult Update(int id)
        {
            var course = context.Courses.AsNoTracking().FirstOrDefault(c => c.Id == id);
            if (course == null)
                return NotFound();

            return View(new CourseVM
            {
                Id = course.Id,
                Name = course.Name,
                Degree = course.Degree,
                MinDegree = course.minDegree,
                DeptId = course.DeptId,
                Departments = GetDepartments()
            });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult SaveUpdate(int id, CourseVM courseVM)
        {
            if (id != courseVM.Id)
                return BadRequest();

            ValidateDepartment(courseVM.DeptId);

            if (!ModelState.IsValid)
            {
                courseVM.Departments = GetDepartments();
                return View(nameof(Update), courseVM);
            }

            var course = context.Courses.FirstOrDefault(c => c.Id == id);
            if (course == null)
                return NotFound();

            course.Name = courseVM.Name.Trim();
            course.Degree = courseVM.Degree;
            course.minDegree = courseVM.MinDegree;
            course.DeptId = courseVM.DeptId;

            context.SaveChanges();
            return RedirectToAction(nameof(Index));
        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
            var course = context.Courses
                .Include(c => c.Dept)
                .AsNoTracking()
                .FirstOrDefault(c => c.Id == id);

            return course == null ? NotFound() : View(course);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult SaveDelete(int id)
        {
            var course = context.Courses.FirstOrDefault(c => c.Id == id);
            if (course == null)
                return NotFound();

            context.Courses.Remove(course);
            context.SaveChanges();
            return RedirectToAction(nameof(Index));
        }

        private List<Department> GetDepartments() =>
            context.Departments.AsNoTracking().OrderBy(d => d.Name).ToList();

        private void ValidateDepartment(int departmentId)
        {
            if (departmentId > 0 && !context.Departments.Any(d => d.Id == departmentId))
                ModelState.AddModelError(nameof(CourseVM.DeptId), "The selected department does not exist.");
        }
    }
}
