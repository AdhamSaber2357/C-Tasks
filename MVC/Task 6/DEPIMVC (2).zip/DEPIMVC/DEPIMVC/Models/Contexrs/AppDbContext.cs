﻿using DEPIMVC.Models.Entities;
using Microsoft.EntityFrameworkCore;

namespace DEPIMVC.Models.Contexrs
{
    public class AppDbContext : DbContext
    {
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Server=.;Database=TaskDB;Trusted_Connection=True;TrustServerCertificate=True;");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Teacher>()
                .HasOne(t => t.Dept)
                .WithMany()
                .HasForeignKey(t => t.DeptId)
                .OnDelete(DeleteBehavior.NoAction); 

            modelBuilder.Entity<Teacher>()
                .HasOne(t => t.Course)
                .WithMany()
                .HasForeignKey(t => t.CourseId)
                .OnDelete(DeleteBehavior.NoAction);

            modelBuilder.Entity<StuCourse>()
           .HasOne(sc => sc.Student)
           .WithMany(s => s.stuCourses)
           .HasForeignKey(sc => sc.StudentId)
           .OnDelete(DeleteBehavior.NoAction);
        }
      public DbSet<Student> Students { get; set; }
      public DbSet<Course> Courses { get; set; }
      public DbSet<Department> Departments { get; set; }
      public DbSet<Teacher> Teachers { get; set; }
      public DbSet<StuCourse> StuCourses { get; set; }

    }
}
