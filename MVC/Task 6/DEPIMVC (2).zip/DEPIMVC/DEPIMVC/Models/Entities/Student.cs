﻿namespace DEPIMVC.Models.Entities
{
    public class Student
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public int? DeptId { get; set; }
        public Department? Dept { get; set; }

        public List<StuCourse> stuCourses { get; set; }
    }
}
