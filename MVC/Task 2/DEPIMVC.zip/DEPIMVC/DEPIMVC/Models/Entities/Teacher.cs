﻿namespace DEPIMVC.Models.Entities
{
    public class Teacher
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Adress { get; set; }
        public double Salary { get; set; }
        public int DeptId { get; set; }
        public Department Dept { get; set; }

        public int CourseId { get; set; }

        public Course Course { get; set; }
    }
}
