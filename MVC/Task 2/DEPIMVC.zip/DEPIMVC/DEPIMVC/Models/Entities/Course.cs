﻿namespace DEPIMVC.Models.Entities
{
    public class Course
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public double Degree { get; set; }
        public double minDegree { get; set; }
        public int DeptId { get; set; }
        public Department Dept { get; set; }

        public List<StuCourse> stuCourses { get; set; }
    }
}
