﻿namespace DEPIMVC.Models.Entities
{
    public class StuCourse
    {
        public int Id { get; set; }
        public double Grade { get; set; }
        public int CourseId { get; set; }
        public Course Course { get; set; }
        public int StudentId { get; set; }
        public Student Student { get; set; }
    }
}
