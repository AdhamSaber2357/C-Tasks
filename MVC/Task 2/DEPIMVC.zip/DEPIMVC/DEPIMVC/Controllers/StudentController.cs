﻿using DEPIMVC.Models.Contexrs;
using DEPIMVC.Models.Entities;
using Microsoft.AspNetCore.Mvc;

namespace DEPIMVC.Controllers
{
    public class StudentController : Controller
    {
        public IActionResult Index()
        {
            AppDbContext context = new();
            var Students = context.Students;
            return View(Students);
        }

        public IActionResult GetStudentById(int id)
        {
            AppDbContext context = new();
            var Student = context.Students.FirstOrDefault(s=>s.Id==id);
            return View(Student);
        }
    }
}
