﻿using DEPI_API.Models;
using Microsoft.EntityFrameworkCore;

namespace DEPI_API.Contexts
{
    public class ApplicationDbContext : DbContext
    {

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }
        

        public DbSet<Course> Courses { get; set; }
    }
}
