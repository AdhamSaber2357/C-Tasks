﻿using DEPI_API.Contexts;
using DEPI_API.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace DEPI_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CourseController : ControllerBase
    {
        private readonly ApplicationDbContext _applicationDbContext;

        public CourseController(ApplicationDbContext applicationDbContext)

        {
            this._applicationDbContext = applicationDbContext;
        }

        [HttpGet]
        public IActionResult get()
        {
            //var courses = _applicationDbContext.Set<Course>().ToList();
            var courses = _applicationDbContext.Courses.ToList();

            if(courses.Any())
                return Ok(courses);

            return NotFound();

        }

        [HttpGet("{id:int}")]
        public IActionResult getById(int id)
        {
            var course = _applicationDbContext.Courses.FirstOrDefault(c=> c.Id == id);

            if (course!=null)
                return Ok(course);

            return NotFound();
        }

        [HttpDelete("{id:int}")]
        public IActionResult deleteCourse(int id)
        {
            var course = _applicationDbContext.Courses.FirstOrDefault(c => c.Id == id);

            if (course == null)
                return NotFound();

            _applicationDbContext.Courses.Remove(course);
            _applicationDbContext.SaveChanges();

            return Ok(_applicationDbContext.Courses.ToList());
        }

        [HttpPut("{id:int}")]
        public IActionResult put(int id, Course? course)
        {
            if (course == null || id != course.Id)
                return BadRequest();

            var existingCourse = _applicationDbContext.Courses.FirstOrDefault(c => c.Id == id);

            if (existingCourse == null)
                return NotFound();

            existingCourse.Name = course.Name;
            existingCourse.crs_desc = course.crs_desc;
            existingCourse.Duration = course.Duration;

            _applicationDbContext.SaveChanges();

            return NoContent();
        }

        [HttpPost]
        public IActionResult post(Course? course)
        {
            if (course == null)
                return BadRequest();

            _applicationDbContext.Courses.Add(course);
            _applicationDbContext.SaveChanges();

            return StatusCode(StatusCodes.Status201Created, course);
        }

        [HttpGet("{name:alpha}")]
        public IActionResult courseByName(string name)
        {
            var course = _applicationDbContext.Courses.FirstOrDefault(c => c.Name == name);

            if (course == null)
                return NotFound();

            return Ok(course);
        }

    }
}
