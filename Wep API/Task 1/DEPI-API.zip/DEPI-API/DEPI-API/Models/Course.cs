﻿namespace DEPI_API.Models
{
    public class Course
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string crs_desc { get; set; }
        public int Duration { get; set; }

    }
}
