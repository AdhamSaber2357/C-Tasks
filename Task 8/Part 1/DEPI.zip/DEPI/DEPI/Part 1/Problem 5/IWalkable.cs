﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DEPI
{
    public interface IWalkable
    {
        void Walk();
    }

    public class Robot : IWalkable
    {
        public void Walk()
        {
            Console.WriteLine("Robot is walking in Normal Mode.");
        }

        void IWalkable.Walk()
        {
            Console.WriteLine("Robot is walking in IWalkable Interface Mode.");
        }
    }
}
