﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DEPI
{
    public class Student : ICloneable
    {

        public int ID { get; set; }
        public string Name { get; set; }
        public double Grade { get; set; }

        public Student(int iD, string name, double grade)
        {
            ID = iD;
            Name = name;
            Grade = grade;
        }

        public object Clone()
        {
            return new Student(ID, Name, Grade);
        }

        public override string ToString()
        {
            return $"ID = {ID} , Name {Name}  , Grade = {Grade}";
        }
    }
}
