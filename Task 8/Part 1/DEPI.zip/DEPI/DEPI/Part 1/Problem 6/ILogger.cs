﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DEPI.Problem_6
{
    public interface ILogger
    {
        public void Log(string message)
        {
            Console.WriteLine($"[Default Logger]: {message}");
        }
    }

    public class ConsoleLogger : ILogger
    {
        public void Log(string message)
        {
            Console.WriteLine($"[Console Logger - Custom]: {message}");
        }
    }

    public class FileLogger : ILogger
    {
    }
}
