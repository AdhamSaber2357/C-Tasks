﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DEPI
{
    public class Product : IComparable<Product>
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public double Price { get; set; }

        public int CompareTo(Product other)
        {
          return this.Price.CompareTo(other.Price);
        }

        public override string ToString()
        {
            return $"ID = {ID} , Name ={Name} , Price = {Price}";
        }
    }
}
