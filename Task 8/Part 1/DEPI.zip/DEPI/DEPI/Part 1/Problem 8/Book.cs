﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DEPI.Problem_8
{
    public class Book
    {
        public string Title { get; set; }
        public string Author { get; set; }

        public Book() : this("Untitled", "Unknown Author")
        {
        }

        public Book(string title) : this(title, "Unknown Author")
        {
        }

        public Book(string title, string author)
        {
            Title = string.IsNullOrWhiteSpace(title) ? "Untitled" : title;
            Author = string.IsNullOrWhiteSpace(author) ? "Unknown Author" : author;
        }

        public void DisplayInfo()
        {
            Console.WriteLine($"Book Title: '{Title}' | Author: {Author}");
        }
    }
}
