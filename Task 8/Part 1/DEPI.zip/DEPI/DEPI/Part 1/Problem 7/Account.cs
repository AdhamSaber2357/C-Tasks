﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DEPI
{
    public struct Account
    {
        private int _accountId;
        private string _accountHolder;
        private decimal _balance;

        public Account(int accountId, string accountHolder, decimal initialBalance)
        {
            _accountId = accountId;
            _accountHolder = accountHolder;
            _balance = initialBalance >= 0 ? initialBalance : 0;
        }

        public int AccountId
        {
            get { return _accountId; }
        }

        public string AccountHolder
        {
            get { return _accountHolder; }
            set
            {
                if (!string.IsNullOrWhiteSpace(value))
                    _accountHolder = value;
            }
        }

        public decimal Balance
        {
            get { return _balance; }
            private set
            {
                if (value >= 0)
                    _balance = value;
            }
        }
    }
}
