﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DEPI
{
    public class Bike : IVehicle
    {
        public void StartEngine()
        {
            Console.WriteLine("Bike Started");
        }

        public void StopEngine()
        {
            Console.WriteLine("Bike Stoped");
        }
    }
}
