﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DEPI
{
    public class Car : IVehicle
    {
        public void StartEngine()
        {
            Console.WriteLine("Car Started");
        }

        public void StopEngine()
        {
            Console.WriteLine("Car Stoped");
        }
    }
}
