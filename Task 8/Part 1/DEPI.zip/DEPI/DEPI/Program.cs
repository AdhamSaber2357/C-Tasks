﻿using DEPI.Part_2.Problem_1;
using DEPI.Part_2.Problem_3;
using DEPI.Problem_6;
using DEPI.Problem_8;
using System;

namespace DEPI
{
    class Program
    {

        public static void PrintTenShapes(IShapeSeries series)
        {
            series.ResetSeries();

            for (int i = 1; i <= 10; i++)
            {
                Console.WriteLine($"Shape {i} Area: {series.CurrentShapeArea}");
                series.GetNextArea();
            }
        }

        public static void SelectionSort(int[] numbers)
        {
            int n = numbers.Length;

            for (int i = 0; i < n - 1; i++)
            {
                int minIndex = i;
                for (int j = i + 1; j < n; j++)
                {
                    if (numbers[j] < numbers[minIndex])
                    {
                        minIndex = j;
                    }
                }

                if (minIndex != i)
                {
                    int temp = numbers[i];
                    numbers[i] = numbers[minIndex];
                    numbers[minIndex] = temp;
                }
            }
        }
        public static int[] GenerateAreasArray(IShapeSeries series, int count)
        {
            int[] areas = new int[count];
            series.ResetSeries();

            for (int i = 0; i < count; i++)
            {
                areas[i] = series.CurrentShapeArea;
                series.GetNextArea();
            }

            return areas;
        }
        static void Main(string[] args)
        {
            // Part 1

            #region Problem 1
            //Car c = new Car();
            //c.StartEngine();
            //c.StopEngine();

            //Console.WriteLine();

            //Bike b = new();
            //b.StartEngine();
            //b.StopEngine();
            //Console.WriteLine();
            //Console.WriteLine();

            #endregion

            #region Problem 2
            //Console.WriteLine("--- 1. Using Abstract Class ---");

            //Shape myRectangle = new Rectangle(5, 10);
            //myRectangle.Display(); 
            //Console.WriteLine($"Rectangle Area: {myRectangle.GetArea()}");

            //Shape myCircle = new Circle(7);
            //myCircle.Display();
            //Console.WriteLine($"Circle Area: {myCircle.GetArea():F2}");

            //Console.WriteLine("\n--- 2. Using Interface ---");

            //IShape myInterfaceCircle = new InterfaceCircle(7);
            //myInterfaceCircle.Display(); 
            //Console.WriteLine($"Interface Circle Area: {myInterfaceCircle.GetArea():F2}");
            #endregion

            #region Problem 3
            //Product[] arr =
            //{
            //    new Product{ID = 1, Name = "Salsa" , Price = 55},
            //    new Product{ID = 2, Name = "Samna" , Price = 41},
            //    new Product{ID = 3, Name = "Zeet" , Price = 21}


            //};
            //Array.Sort(arr);

            //foreach (var item in arr)
            //{
            //    Console.WriteLine(item);
            //}
            #endregion

            #region Problem 4
            //Student s1 = new Student(1, "Adham", 85);
            //Student s2 = (Student) s1.Clone();

            //Console.WriteLine(s1);
            //Console.WriteLine(s1.GetHashCode());
            //Console.WriteLine();
            //Console.WriteLine(s2);
            //Console.WriteLine(s2.GetHashCode());

            #endregion

            #region Problem 5
            //Robot myRobot = new Robot();

            //myRobot.Walk();

            //IWalkable walkableRobot = myRobot;
            //walkableRobot.Walk(); 

            //((IWalkable)myRobot).Walk();
            #endregion

            #region Problem 6
            //Account myAccount = new Account(1001, "Adham Saber", 5000.00m);

            //Console.WriteLine(myAccount.AccountId);
            //Console.WriteLine(myAccount.AccountHolder);
            //Console.WriteLine(myAccount.Balance);

            #endregion

            #region Problem 7
            //ILogger customLogger = new ConsoleLogger();
            //customLogger.Log("System initialized successfully.");

            //Console.WriteLine();

            //ILogger defaultLogger = new FileLogger();
            //defaultLogger.Log("Unhandled exception occurred.");
            #endregion

            #region Problem 8
            //Book book1 = new Book();
            //Console.Write("1. Default Constructor: ");
            //book1.DisplayInfo();

            //Book book2 = new Book("Clean Code");
            //Console.Write("2. Title-only Constructor: ");
            //book2.DisplayInfo();

            //Book book3 = new Book("The C++ Programming Language", "Bjarne Stroustrup");
            //Console.Write("3. Full Constructor: ");
            //book3.DisplayInfo();
            #endregion


            // Part 2

            #region p1
            //Console.WriteLine("=== Square Series (Side: 1, 2, 3...) ===");
            //IShapeSeries squareSeries = new SquareSeries();
            //PrintTenShapes(squareSeries);

            //Console.WriteLine("\n=== Circle Series (Radius: 1, 2, 3...) ===");
            //IShapeSeries circleSeries = new CircleSeries();
            //PrintTenShapes(circleSeries);
            #endregion

            #region p2

            //DEPI.Part_2.Problem_2.Shape s1 = new("Circle",50) ;
            //DEPI.Part_2.Problem_2.Shape s2 = new("Square",70) ;
            //DEPI.Part_2.Problem_2.Shape s3 = new("Rectangle",20) ;

            //DEPI.Part_2.Problem_2.Shape[] arr =
            //{

            //    new DEPI.Part_2.Problem_2.Shape ("Circle",50) ,
            //     new DEPI.Part_2.Problem_2.Shape ("Square", 70),
            //  new   DEPI.Part_2.Problem_2.Shape("Rectangle", 20)

            //};

            //Array.Sort(arr);
            //foreach (var i in arr)
            //{

            //    Console.WriteLine(i);
            //}

            #endregion

            #region p3
            //GeometricShape triangle = new Triangle(6, 8);
            //Console.WriteLine("--- Triangle ---");
            //Console.WriteLine($"Base: {triangle.Dimension1}, Height: {triangle.Dimension2}");
            //Console.WriteLine($"Area: {triangle.CalculateArea()}");
            //Console.WriteLine($"Perimeter: {triangle.Perimeter:F2}");

            //Console.WriteLine();

            //GeometricShape rectangle = new DEPI.Part_2.Problem_3.Rectangle(5, 10);
            //Console.WriteLine("--- Rectangle ---");
            //Console.WriteLine($"Width: {rectangle.Dimension1}, Height: {rectangle.Dimension2}");
            //Console.WriteLine($"Area: {rectangle.CalculateArea()}");
            //Console.WriteLine($"Perimeter: {rectangle.Perimeter}");
            #endregion

            #region p4

            //IShapeSeries squareSeries = new SquareSeries();
            //int[] shapeAreas = GenerateAreasArray(squareSeries, 7);

            //Array.Reverse(shapeAreas);

            //Console.WriteLine("Original Unsorted Areas:");
            //Console.WriteLine(string.Join(", ", shapeAreas));

            //SelectionSort(shapeAreas);

            //Console.WriteLine("\nSorted Areas (Selection Sort):");
            //Console.WriteLine(string.Join(", ", shapeAreas));
            #endregion

          
        }
    }

    


    

}
