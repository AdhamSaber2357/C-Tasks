﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DEPI.Part_2.Problem_3
{
    public abstract class GeometricShape
    {
        public double Dimension1 { get; set; }
        public double Dimension2 { get; set; }

        public GeometricShape(double dim1, double dim2)
        {
            Dimension1 = dim1;
            Dimension2 = dim2;
        }

        public abstract double CalculateArea();

        public abstract double Perimeter { get; }
    }

    public class Triangle : GeometricShape
    {
        public Triangle(double baseLength, double height) : base(baseLength, height)
        {
        }

        public override double CalculateArea()
        {
            return 0.5 * Dimension1 * Dimension2;
        }

        public override double Perimeter
        {
            get
            {
                double hypotenuse = Math.Sqrt((Dimension1 * Dimension1) + (Dimension2 * Dimension2));
                return Dimension1 + Dimension2 + hypotenuse;
            }
        }
    }

    public class Rectangle : GeometricShape
    {
        public Rectangle(double width, double height) : base(width, height)
        {
        }

        public override double CalculateArea()
        {
            return Dimension1 * Dimension2; 
        }

        public override double Perimeter
        {
            get
            {
                return 2 * (Dimension1 + Dimension2); 
            }
        }
    }
}
