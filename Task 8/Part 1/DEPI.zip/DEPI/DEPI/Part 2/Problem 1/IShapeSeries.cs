﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DEPI.Part_2.Problem_1
{
    public interface IShapeSeries
    {
        int CurrentShapeArea { get; set; }
        void GetNextArea();
        void ResetSeries();
    }

    public class SquareSeries : IShapeSeries
    {
        private int _sideLength;

        public int CurrentShapeArea { get; set; }

        public SquareSeries()
        {
            ResetSeries();
        }

        public void GetNextArea()
        {
            _sideLength++;
            CurrentShapeArea = _sideLength * _sideLength;
        }

        public void ResetSeries()
        {
            _sideLength = 1;
            CurrentShapeArea = _sideLength * _sideLength; 
        }
    }

    public class CircleSeries : IShapeSeries
    {
        private int _radius;

        public int CurrentShapeArea { get; set; }

        public CircleSeries()
        {
            ResetSeries();
        }

        public void GetNextArea()
        {
            _radius++;
            CurrentShapeArea = (int)Math.Round(Math.PI * _radius * _radius);
        }

        public void ResetSeries()
        {
            _radius = 1;
            CurrentShapeArea = (int)Math.Round(Math.PI * _radius * _radius); 
        }
    }
}
