﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DEPI.Part_2.Problem_2
{
    public class Shape : IComparable<Shape>
    {

        public string Name { get; set; }
        public double Area { get; set; }

        public Shape(string name, double area)
        {
            Name = name;
            Area = area;
        }


        public override string ToString()
        {
            return $"Name =  {Name} , Area = {Area} ";
        }

        public int CompareTo(Shape other)
        {
           return Area.CompareTo(other.Area);
        }
    }
}
